"""Let's Encrypt compatibility test errors"""


class Error(Exception):
    """Generic Let's Encrypt compatibility test error"""
